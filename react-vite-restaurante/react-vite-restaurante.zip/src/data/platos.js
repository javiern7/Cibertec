export const platos = [
  { id: 1, nombre: "Ceviche Mixto", imagen: "https://larepublica.cronosmedia.glr.pe/migration/images/ZHKC2OWWG5ALTBKKOX4HO7JLDA.jpg", precio: 35.50},
  { id: 2, nombre: "Lomo Saltado", imagen: "https://buenazo.cronosmedia.glr.pe/original/2022/06/20/62aea00d119a8801813a563b.jpg", precio: 39.45 },
  { id: 3, nombre: "Aji de Gallina", imagen: "https://blog.plazavea.com.pe/wp-content/uploads/2023/01/aji-de-gallina-1200x675.jpg", precio: 21.50 },
  { id: 4, nombre: "Anticuchos", imagen: "https://www.infobae.com/resizer/v2/QZSNOD4HEZF7FHCC52RLRFRVNE.png?auth=81cbe50ce29cc18e2602dc3ab3a2728007aed04d87ace1a8607e25661dc5252c&smart=true&width=1200&height=675&quality=85", precio: 20.33 },
  { id: 5, nombre: "Tacu Tacu", imagen: "https://comedera.com/wp-content/uploads/sites/9/2022/03/Tacu-tacu-shutterstock_1604013508.jpg", precio: 28.77 },
  { id: 6, nombre: "Pollo a la Brasa", imagen: "https://blog.sanfernando.pe/wp-content/uploads/2023/07/banner_3.jpg", precio: 21.68 },
  { id: 7, nombre: "Rocoto Relleno", imagen: "https://mojo.generalmills.com/api/public/content/O-OFmxjsVUynqsFBv2xWWQ_gmi_hi_res_jpeg.jpeg?v=48a505e6&t=16e3ce250f244648bef28c5949fb99ff", precio: 18.44 },
  { id: 8, nombre: "Carapulcra", imagen: "https://elmen.pe/wp-content/uploads/2022/07/CARAPULCRA.jpg", precio: 18.66 },
  { id: 9, nombre: "Cuy Chactado", imagen: "https://jameaperu.com/assets/images/cuy-chactado_800x534.webp", precio: 33.42 },
  { id: 10, nombre: "Seco de Cabrito", imagen: "https://imgmedia.buenazo.pe/1200x700/buenazo/original/2023/06/08/648288b91e752527c9414bf2.png", precio: 28.85 },
  { id: 11, nombre: "Pachamanca", imagen: "https://cloudfront-us-east-1.images.arcpublishing.com/infobae/XQ6NDUNECJE3ZGJBXV5ATSPCC4.png", precio: 48.99 },
  { id: 12, nombre: "Sudado de Pescado", imagen: "https://www.apega.pe/wp-content/uploads/2025/05/receta-de-sudado-de-pescado-800x445.jpg.webp", precio: 31.50 },
  { id: 13, nombre: "Chupe de Camarones", imagen: "https://origin.cronosmedia.glr.pe/large/2023/07/28/lg_64c4657e51e2d31acf06c044.jpg", precio: 27.60 },
  { id: 14, nombre: "Chicharrón de Calamar", imagen: "https://i.ytimg.com/vi/MZwro2DS77M/maxresdefault.jpg", precio: 22.38 },
  { id: 15, nombre: "Papa a la Huancaína", imagen: "https://imgmedia.buenazo.pe/1200x660/buenazo/original/2020/09/25/5f6eaf8e2810e95b5c5da50c.jpg", precio: 12.87 }
];
